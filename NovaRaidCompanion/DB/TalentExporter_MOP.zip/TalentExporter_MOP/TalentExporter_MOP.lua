_, NTE = ...;
local talentData = {};
--Created by Venomisto (Novaspark-Arugal)
--Exports the same data structure as earlier versions of the Talented addon.
--Modify the NTE:generateTalentData() func to suit your data structure needs.

--Preloaded with cata talents for all classes.

--If you want a diff expansion:
--Download Talent.csv from wago tools, run this lib https://github.com/geoffleyland/lua-csv.
--Paste the data table below.

--[[
local csv = require("lua-csv/lua/csv")
local f = csv.open("Talent.csv")
print("local data = {")
for row in f:lines() do
    local talentID = row[1];
    local tier1 = row[14];
    local tier2 = row[15];
    local tier3 = row[16];
    local tier4 = row[17];
    local tier5 = row[18];
    print("\t[" .. talentID .. "]={" .. tier1 .. "," .. tier2 .. "," .. tier3 .. "," .. tier4 .. "," .. tier5 .. "},");
end
print("};")
]]

--Cata data.
--[talentID] = {tier1,tier2,tier3,tier4,tier5}
local data = {
	--[23]={11083,12351,0,0,0},
};

---The above stuff is no longer used for MoP and onwards in the new tier talents system.
---Now we just get everything from ingame to create our db.

local function updateSavedVariables()
	local count, spellIDs = 0, 0;
	for row, rowData in pairs(talentData) do
		for column, columnData in pairs(rowData) do
			count = count + 1;
			if (columnData.spellID) then
				spellIDs = spellIDs + 1;
			end
		end
	end
	--NRC:debug(talentData)
	NTEdatabase = talentData;
	--NTE:printOutput(); --Print table to chat.
	NTE:openCopyFrame(); --Open a copy text frame with the table ready to ctrl + v.
	print("Talent DB exported - Talents recorded with SpellID entries:", spellIDs .. "/" .. count);
end

local function debug(...)
	local data = ...;
	if (data) then
		if (type(data) == "table") then
			UIParentLoadAddOn("Blizzard_DebugTools");
			--DevTools_Dump(data);
    		DisplayTableInspectorWindow(data);
    	else
			print("TEDebug:", ...);
		end
	end
end

local function pairsByKeys(t, f)
	local a = {};
	for n in pairs(t) do
		tinsert(a, n);
	end
	table.sort(a, f);
	local i = 0;
	local iter = function()
		i = i + 1;
		if (a[i] == nil) then
			return nil;
		else
			return a[i], t[a[i]];
		end
	end
	return iter;
end

--local tooltipScanner = CreateFrame("GameTooltip", "NTETooltipScanner", nil, "GameTooltipTemplate");
--tooltipScanner:SetOwner(WorldFrame, "ANCHOR_NONE");

function NTE:generateTalentData()
	talentData = {};
	for row = 1, MAX_NUM_TALENT_TIERS do
		talentData[row] = {};
		for column = 1, NUM_TALENT_COLUMNS do
			local talentInfoQuery = {};
			talentInfoQuery.tier = row;
			talentInfoQuery.column= column;
			--talentInfoQuery.groupIndex = TalentFrame.talentGroup;
			--talentInfoQuery.isInspect = TalentFrame.inspect;
			--talentInfoQuery.target = talentUnit;
			local talentInfo = C_SpecializationInfo.GetTalentInfo(talentInfoQuery);
			if (talentInfo) then
				--Don't need to tooltip scan for spellID anymore.
				--tooltipScanner:SetTalent(talentInfo.talentID);
				--local _, spellID = tooltipScanner:GetSpell();
				talentData[row][column] = {
					row = row,
					column = column,
					icon = talentInfo.icon,
					name = talentInfo.name,
					talentID = talentInfo.talentID;
					spellID = talentInfo.spellID,
				};
				
				--Old way using wago db.
				--Insert spellID.
				--if (data[talentInfo.talentID]) then
				--	talentData[row][column].spellID = data[talentInfo.talentID];
				--end
			end
		end
	end
	updateSavedVariables();
end

local f = CreateFrame("Frame");
f:RegisterEvent("PLAYER_ENTERING_WORLD");
f:SetScript("OnEvent", function(self, event, ...)
	NTE:generateTalentData();
	f:UnregisterEvent("PLAYER_ENTERING_WORLD");
end)


--Print to chat when we record, it's a neater table structure to copy and paste than the saved variables file.
function NTE:printOutput()
	local _, class = UnitClass("player");
	print("talents." .. strlower(class) .. " = {");
	for k, v in pairs(talentData) do
		print("    [" .. k .. "] = {");
			for k, v in pairs(v) do
				print("        [" .. k .. "] = {");
				print("            [\"name\"] = \"" .. v.name .. "\",");
				print("            [\"row\"] = " .. v.row .. ",");
				print("            [\"column\"] = " .. v.column .. ",");
				print("            [\"talentID\"] = " .. v.talentID .. ",");
				print("            [\"spellID\"] = " .. v.spellID .. ",");
				print("            [\"icon\"] = " .. v.icon .. ",");
				print("        },");
			end
		print("    },");
	end
	print("};");
end

local NTECopyFrame = CreateFrame("ScrollFrame", "NTECopyFrame", nil, "BackdropTemplate,InputScrollFrameTemplate");
NTECopyFrame:Hide();
NTECopyFrame:SetToplevel(true);
NTECopyFrame:SetMovable(true);
NTECopyFrame:EnableMouse(true);
NTECopyFrame:SetHeight(245);
NTECopyFrame:SetWidth(400);
NTECopyFrame.EditBox:SetWidth(NTECopyFrame:GetWidth() - 30);
tinsert(UISpecialFrames, "NTECopyFrame");
NTECopyFrame:SetPoint("CENTER", UIParent, -100, 100);
NTECopyFrame:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8x8",insets = {top = 0, left = 0, bottom = 0, right = 0}});
NTECopyFrame:SetBackdropColor(0,0,0,.5);
NTECopyFrame.CharCount:Hide();
NTECopyFrame:SetFrameLevel(129);
NTECopyFrame:SetFrameStrata("TOOLTIP");
local NTECopyFrameTopBar = CreateFrame("Frame", "NTECopyFrameTopBar", NTECopyFrame, "ThinGoldEdgeTemplate");
NTECopyFrameTopBar:SetPoint("TOP", -8, 22);
NTECopyFrameTopBar:SetWidth(120);
NTECopyFrameTopBar:SetHeight(18);
NTECopyFrameTopBar.fs = NTECopyFrameTopBar:CreateFontString("topBarFS", "OVERLAY", "NumberFont_Shadow_Tiny");
NTECopyFrameTopBar.fs:SetText("|cFFFFFF00Nova Talent Exporter");
NTECopyFrameTopBar.fs:SetPoint("CENTER", 0, 0);
NTECopyFrameTopBar:SetMovable(true);
NTECopyFrameTopBar:EnableMouse(true);
NTECopyFrameTopBar:SetScript("OnMouseDown", function(self, button)
	if (button == "LeftButton" and not self:GetParent().isMoving) then
		self:GetParent():StartMoving();
		self:GetParent().isMoving = true;
	end
end)
NTECopyFrameTopBar:SetScript("OnMouseUp", function(self, button)
	if (button == "LeftButton" and self:GetParent().isMoving) then
		self:GetParent():StopMovingOrSizing();
		self:GetParent().isMoving = false;
	end
end)
NTECopyFrameTopBar:SetScript("OnHide", function(self)
	if (self:GetParent().isMoving) then
		self:GetParent():StopMovingOrSizing();
		self:GetParent().isMoving = false;
	end
end)

--Top right X close button
local NTECopyFrameCloseButton = CreateFrame("Button", "NTECopyFrameCloseButton", NTECopyFrame, "UIPanelCloseButton");
NTECopyFrameCloseButton:SetPoint("TOPRIGHT", 12, 27);
NTECopyFrameCloseButton:SetWidth(29);
NTECopyFrameCloseButton:SetHeight(29);
NTECopyFrameCloseButton:SetScript("OnClick", function(self, arg)
	NTECopyFrame:Hide();
end)

function NTE:openCopyFrame()
	NTECopyFrame.EditBox:SetFont("Fonts\\ARIALN.ttf", 11, "");
	NTECopyFrame.EditBox:SetText("");
	local _, class = UnitClass("player");
	local text = "talents." .. strlower(class) .. " = {";
	for k, v in pairs(talentData) do
		text = text .. "\n    [" .. k .. "] = {";
			for k, v in pairs(v) do
				text = text .. "\n        [" .. k .. "] = {";
				text = text .. "\n            [\"name\"] = \"" .. v.name .. "\",";
				text = text .. "\n            [\"row\"] = " .. v.row .. ",";
				text = text .. "\n            [\"column\"] = " .. v.column .. ",";
				text = text .. "\n            [\"talentID\"] = " .. v.talentID .. ",";
				text = text .. "\n            [\"spellID\"] = " .. v.spellID .. ",";
				text = text .. "\n            [\"icon\"] = " .. v.icon .. ",";
				text = text .. "\n        },";
			end
		text = text .. "\n    },";
	end
	text = text .. "\n};";
	NTECopyFrame.EditBox:Insert(text);
	NTECopyFrame:Show();
	NTECopyFrame.EditBox:HighlightText();
	NTECopyFrame.EditBox:SetFocus();
end