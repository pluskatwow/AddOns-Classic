_, NEE = ...;
local encounterData = {};
--Created by Venomisto (Novaspark-Arugal)
--Exports the same data structure as earlier versions of the Talented addon.
--Modify the NTE:generateencounterData() func to suit your data structure needs.

local data = {
	["Name_lang"] = ID,
	["Elder Nadox"] = 212,
	["Prince Taldaram"] = 213,
	["Jedoga Shadowseeker"] = 214,
	["Herald Volazj"] = 215,
	["Krik'thir the Gatewatcher"] = 216,
	["Hadronox"] = 217,
	["Anub'arak"] = 218,
	["Ghamoo-ra"] = 219,
	["Lady Sarevess"] = 220,
	["Gelihast"] = 221,
	["Lorgus Jett"] = 222,
	["Old Serra'kis"] = 224,
	["Twilight Lord Kelris"] = 225,
	["Aku'mai"] = 226,
	["High Interrogator Gerstahn"] = 227,
	["Lord Roccor"] = 228,
	["Houndmaster Grebmar"] = 229,
	["Ring of Law"] = 230,
	["Pyromancer Loregrain"] = 231,
	["Lord Incendius"] = 232,
	["Warder Stilgiss"] = 233,
	["Fineous Darkvire"] = 234,
	["Bael'Gar"] = 235,
	["General Angerforge"] = 236,
	["Golem Lord Argelmach"] = 237,
	["Hurley Blackbreath"] = 238,
	["Phalanx"] = 239,
	["Ribbly Screwspigot"] = 240,
	["Plugger Spazzring"] = 241,
	["Ambassador Flamelash"] = 242,
	["The Seven"] = 243,
	["Magmus"] = 244,
	["Emperor Dagran Thaurissan"] = 245,
	["Yor"] = 250,
	["Highlord Omokk"] = 267,
	["Shadow Hunter Vosh'gajin"] = 268,
	["War Master Voone"] = 269,
	["Mother Smolderweb"] = 270,
	["Urok Doomhowl"] = 271,
	["Quartermaster Zigris"] = 272,
	["Gizrul the Slavener"] = 273,
	["Halycon"] = 274,
	["Overlord Wyrmthalak"] = 275,
	["Pyroguard Emberseer"] = 276,
	["Solakar Flamewreath"] = 277,
	["Warchief Rend Blackhand"] = 278,
	["The Beast"] = 279,
	["General Drakkisath"] = 280,
	["Meathook"] = 293,
	["Salram the Fleshcrafter"] = 294,
	["Chrono-Lord Epoch"] = 295,
	["Mal'ganis"] = 296,
	["Grand Champions"] = 334,
	["Argent Champion"] = 338,
	["The Black Knight"] = 340,
	["Zevrim Thornhoof"] = 343,
	["Hydrospawn"] = 344,
	["Lethtendris"] = 345,
	["Alzzin the Wildshaper"] = 346,
	["Illyanna Ravenoak"] = 347,
	["Magister Kalendris"] = 348,
	["Immol'thar"] = 349,
	["Tendris Warpwood"] = 350,
	["Prince Tortheldrin"] = 361,
	["Guard Mol'dar"] = 362,
	["Stomper Kreeg"] = 363,
	["Guard Fengus"] = 364,
	["Guard Slip'kik"] = 365,
	["Captain Kromcrush"] = 366,
	["Cho'Rush the Observer"] = 367,
	["King Gordok"] = 368,
	["Trollgore"] = 369,
	["Novos the Summoner"] = 371,
	["King Dred"] = 373,
	["The Prophet Tharon'ja"] = 375,
	["Viscous Fallout"] = 378,
	["Grubbis"] = 379,
	["Electrocutioner 6000"] = 380,
	["Crowd Pummeler 9-60"] = 381,
	["Mekgineer Thermaplugg"] = 382,
	["Slad'ran"] = 383,
	["Drakkari Colossus"] = 385,
	["Moorabi"] = 387,
	["Gal'darah"] = 390,
	["Noxxion"] = 422,
	["Razorlash"] = 423,
	["Lord Vyletongue"] = 424,
	["Celebras the Cursed"] = 425,
	["Landslide"] = 426,
	["Tinkerer Gizlock"] = 427,
	["Rotgrip"] = 428,
	["Princess Theradras"] = 429,
	["Tuten'kash"] = 434,
	["Mordresh Fire Eye"] = 435,
	["Glutton"] = 436,
	["Amnennar the Coldbringer"] = 437,
	["Roogug"] = 438,
	["Aggem Thorncurse"] = 439,
	["Death Speaker Jargba"] = 440,
	["Overlord Ramtusk"] = 441,
	["Charlga Razorflank"] = 443,
	["Interrogator Vishas"] = 444,
	["Houndmaster Loksey"] = 446,
	["Arcanist Doan"] = 447,
	["Herod"] = 448,
	["High Inquisitor Fairbanks"] = 449,
	["High Inquisitor Whitemane"] = 450,
	["The Unforgiven"] = 472,
	["Hearthsinger Forresten"] = 473,
	["Timmy the Cruel"] = 474,
	["Willey Hopebreaker"] = 475,
	["Commander Malor"] = 476,
	["Instructor Galford"] = 477,
	["Balnazzar"] = 478,
	["Baroness Anastari"] = 479,
	["Nerub'enkan"] = 480,
	["Maleki the Pallid"] = 481,
	["Magistrate Barthilas"] = 482,
	["Ramstein the Gorger"] = 483,
	["Lord Aurius Rivendare"] = 484,
	["Dreamscythe"] = 486,
	["Weaver"] = 487,
	["Jammal'an the Prophet"] = 488,
	["Morphaz"] = 490,
	["Hazzas"] = 491,
	["Avatar of Hakkar"] = 492,
	["Shade of Eranikus"] = 493,
	["Frozen Commander"] = 519,
	["Grand Magus Telestra"] = 520,
	["Anomalus"] = 522,
	["Ormorok the Tree-Shaper"] = 524,
	["Keristrasza"] = 526,
	["Drakos the Interrogator"] = 528,
	["Varos Cloudstrider"] = 530,
	["Mage-Lord Urom"] = 532,
	["Ley-Guardian Eregos"] = 534,
	["First Prisoner"] = 541,
	["Second Prisoner"] = 543,
	["Cyanigosa"] = 545,
	["Revelosh"] = 547,
	["The Lost Dwarves"] = 548,
	["Ironaya"] = 549,
	["Ancient Stone Keeper"] = 551,
	["Galgann Firehammer"] = 552,
	["Grimlok"] = 553,
	["Archaedas"] = 554,
	["General Bjarngrim"] = 555,
	["Volkhan"] = 557,
	["Ionar"] = 559,
	["Loken"] = 561,
	["Krystallus"] = 563,
	["Maiden of Grief"] = 565,
	["Tribunal of Ages"] = 567,
	["Sjonnir the Ironshaper"] = 569,
	["Prince Keleseth"] = 571,
	["Skarvold & Dalronn"] = 573,
	["Ingvar the Plunderer"] = 575,
	["Svala Sorrowgrave"] = 577,
	["Gortok Palehoof"] = 579,
	["Skadi the Ruthless"] = 581,
	["King Ymiron"] = 583,
	["Lady Anacondra"] = 585,
	["Lord Cobrahn"] = 586,
	["Kresh"] = 587,
	["Lord Pythas"] = 588,
	["Skum"] = 589,
	["Lord Serpentis"] = 590,
	["Verdan the Everliving"] = 591,
	["Mutanus the Devourer"] = 592,
	["Hydromancer Velratha"] = 593,
	["Ghaz'rilla"] = 594,
	["Antu'sul"] = 595,
	["Theka the Martyr"] = 596,
	["Witch Doctor Zum'rah"] = 597,
	["Nekrum Gutchewer"] = 598,
	["Shadowpriest Sezz'ziz"] = 599,
	["Chief Ukorz Sandscalp"] = 600,
	["High Warlord Naj'entus"] = 601,
	["Supremus"] = 602,
	["Shade of Akama"] = 603,
	["Teron Gorefiend"] = 604,
	["Gurtogg Bloodboil"] = 605,
	["Reliquary of Souls"] = 606,
	["Mother Shahraz"] = 607,
	["The Illidari Council"] = 608,
	["Illidan Stormrage"] = 609,
	["Razorgore the Untamed"] = 610,
	["Vaelastrasz the Corrupt"] = 611,
	["Broodlord Lashlayer"] = 612,
	["Firemaw"] = 613,
	["Ebonroc"] = 614,
	["Flamegor"] = 615,
	["Chromaggus"] = 616,
	["Nefarian"] = 617,
	["Rage Winterchill"] = 618,
	["Anetheron"] = 619,
	["Kaz'rogal"] = 620,
	["Azgalor"] = 621,
	["Archimonde"] = 622,
	["Hydross the Unstable"] = 623,
	["The Lurker Below"] = 624,
	["Leotheras the Blind"] = 625,
	["Fathom-Lord Karathress"] = 626,
	["Morogrim Tidewalker"] = 627,
	["Lady Vashj"] = 628,
	["High King Maulgar"] = 649,
	["Gruul the Dragonkiller"] = 650,
	["Magtheridon"] = 651,
	["Attumen the Huntsman"] = 652,
	["Moroes"] = 653,
	["Maiden of Virtue"] = 654,
	["Opera Hall"] = 655,
	["The Curator"] = 656,
	["Terestian Illhoof"] = 657,
	["Shade of Aran"] = 658,
	["Netherspite"] = 659,
	["Chess Event"] = 660,
	["Prince Malchezaar"] = 661,
	["Nightbane"] = 662,
	["Lucifron"] = 663,
	["Magmadar"] = 664,
	["Gehennas"] = 665,
	["Garr"] = 666,
	["Shazzrah"] = 667,
	["Baron Geddon"] = 668,
	["Sulfuron Harbinger"] = 669,
	["Golemagg the Incinerator"] = 670,
	["Majordomo Executus"] = 671,
	["Ragnaros"] = 672,
	["The Prophet Skeram"] = 709,
	["Silithid Royalty"] = 710,
	["Battleguard Sartura"] = 711,
	["Fankriss the Unyielding"] = 712,
	["Viscidus"] = 713,
	["Princess Huhuran"] = 714,
	["Twin Emperors"] = 715,
	["Ouro"] = 716,
	["C'thun"] = 717,
	["Kurinnaxx"] = 718,
	["General Rajaxx"] = 719,
	["Moam"] = 720,
	["Buru the Gorger"] = 721,
	["Ayamiss the Hunter"] = 722,
	["Ossirian the Unscarred"] = 723,
	["Kalecgos"] = 724,
	["Brutallus"] = 725,
	["Felmyst"] = 726,
	["Eredar Twins"] = 727,
	["M'uru"] = 728,
	["Kil'jaeden"] = 729,
	["Al'ar"] = 730,
	["Void Reaver"] = 731,
	["High Astromancer Solarian"] = 732,
	["Kael'thas Sunstrider"] = 733,
	["High Priest Venoxis"] = 784,
	["High Priestess Jeklik"] = 785,
	["High Priestess Mar'li"] = 786,
	["Bloodlord Mandokir"] = 787,
	["Edge of Madness"] = 788,
	["High Priest Thekal"] = 789,
	["Gahz'ranka"] = 790,
	["High Priestess Arlokk"] = 791,
	["Jin'do the Hexxer"] = 792,
	["Hakkar"] = 793,
	["Bronjahm"] = 829,
	["Devourer of Souls"] = 831,
	["Forgemaster Garfrost"] = 833,
	["Krick"] = 835,
	["Scourgelord Tyrannus"] = 837,
	["Marwyn"] = 839,
	["Falric"] = 841,
	["Escaped from Arthas"] = 843,
	["Agathelos the Raging"] = 883,
	["Atramedes"] = 1022,
	["Chimaeron"] = 1023,
	["Magmaw"] = 1024,
	["Maloriak"] = 1025,
	["Nefarian's End"] = 1026,
	["Omnotron Defense System"] = 1027,
	["Ascendant Council"] = 1028,
	["Cho'gall"] = 1029,
	["Halfus Wyrmbreaker"] = 1030,
	["Theralion and Valiona"] = 1032,
	["Argaloth"] = 1033,
	["Al'Akir"] = 1034,
	["Conclave of Wind"] = 1035,
	["Ascendant Lord Obsidius"] = 1036,
	["Beauty"] = 1037,
	["Corla, Herald of Twilight"] = 1038,
	["Karsh Steelbender"] = 1039,
	["Rom'ogg Bonecrusher"] = 1040,
	["Altairus"] = 1041,
	["Asaad"] = 1042,
	["Grand Vizier Ertan"] = 1043,
	["Commander Ulthok"] = 1044,
	["Lady Naz'jar"] = 1045,
	["Mindbender Ghur'sha"] = 1046,
	["Ozumat"] = 1047,
	["Drahga Shadowburner"] = 1048,
	["Erudax"] = 1049,
	["Forgemaster Throngus"] = 1050,
	["General Umbriss"] = 1051,
	["General Husam"] = 1052,
	["High Prophet Barim"] = 1053,
	["Lockmaw"] = 1054,
	["Siamat"] = 1055,
	["Corborus"] = 1056,
	["High Priestess Azil"] = 1057,
	["Ozruk"] = 1058,
	["Slabhide"] = 1059,
	["\"Captain\" Cookie"] = 1060,
	["Admiral Ripsnarl"] = 1062,
	["Foe Reaper 5000"] = 1063,
	["Glubtok"] = 1064,
	["Helix Gearbreaker"] = 1065,
	["Baron Ashbury"] = 1069,
	["Baron Silverlaine"] = 1070,
	["Commander Springvale"] = 1071,
	["Lord Godfrey"] = 1072,
	["Lord Walden"] = 1073,
	["Ammunae"] = 1074,
	["Anraphet"] = 1075,
	["Earthrager Ptah"] = 1076,
	["Isiset"] = 1077,
	["Rajh"] = 1078,
	["Setesh"] = 1079,
	["Temple Guardian Anhuur"] = 1080,
	["Vanessa VanCleef"] = 1081,
	["Sinestra"] = 1082,
	["Onyxia"] = 1084,
	["Anub'arak"] = 1085,
	["Faction Champions"] = 1086,
	["Lord Jaraxxus"] = 1087,
	["Northrend Beasts"] = 1088,
	["Val'kyr Twins"] = 1089,
	["Sartharion"] = 1090,
	["Shadron"] = 1091,
	["Tenebron"] = 1092,
	["Vesperon"] = 1093,
	["Malygos"] = 1094,
	["Blood Council"] = 1095,
	["Deathbringer Saurfang"] = 1096,
	["Festergut"] = 1097,
	["Valithria Dreamwalker"] = 1098,
	["Icecrown Gunship Battle"] = 1099,
	["Lady Deathwhisper"] = 1100,
	["Lord Marrowgar"] = 1101,
	["Professor Putricide"] = 1102,
	["Queen Lana'thel"] = 1103,
	["Rotface"] = 1104,
	["Sindragosa"] = 1105,
	["The Lich King"] = 1106,
	["Anub'Rekhan"] = 1107,
	["Gluth"] = 1108,
	["Gothik the Harvester"] = 1109,
	["Grand Widow Faerlina"] = 1110,
	["Grobbulus"] = 1111,
	["Heigan the Unclean"] = 1112,
	["Instructor Razuvious"] = 1113,
	["Kel'Thuzad"] = 1114,
	["Loatheb"] = 1115,
	["Maexxna"] = 1116,
	["Noth the Plaguebringer"] = 1117,
	["Patchwerk"] = 1118,
	["Sapphiron"] = 1119,
	["Thaddius"] = 1120,
	["The Four Horsemen"] = 1121,
	["Archavon the Stone Watcher"] = 1126,
	["Emalon the Storm Watcher"] = 1127,
	["Koralon the Flame Watcher"] = 1128,
	["Toravon the Ice Watcher"] = 1129,
	["Algalon the Observer"] = 1130,
	["Auriaya"] = 1131,
	["Flame Leviathan"] = 1132,
	["Freya"] = 1133,
	["General Vezax"] = 1134,
	["Hodir"] = 1135,
	["Ignis the Furnace Master"] = 1136,
	["Kologarn"] = 1137,
	["Mimiron"] = 1138,
	["Razorscale"] = 1139,
	["The Assembly of Iron"] = 1140,
	["Thorim"] = 1141,
	["XT-002 Deconstructor"] = 1142,
	["Yogg-Saron"] = 1143,
	["Hogger"] = 1144,
	["Lord Overheat"] = 1145,
	["Randolph Moloch"] = 1146,
	["Baltharus the Warborn"] = 1147,
	["General Zarithrian"] = 1148,
	["Saviana Ragefire"] = 1149,
	["Halion"] = 1150,
	["Elder Brightleaf"] = 1164,
	["Elder Ironbranch"] = 1165,
	["Elder Stonebark"] = 1166,
	["High Priest Venoxis"] = 1178,
	["Bloodlord Mandokir"] = 1179,
	["High Priestess Kilnara"] = 1180,
	["Zanzil"] = 1181,
	["Jin'do the Godbreaker"] = 1182,
	["Majordomo Staghelm"] = 1185,
	["Cache of Madness"] = 1188,
	["Akil'zon"] = 1189,
	["Nalorakk"] = 1190,
	["Jan'alai"] = 1191,
	["Halazzi"] = 1192,
	["Hex Lord Malacrass"] = 1193,
	["Daakara"] = 1194,
	["Beth'tilac"] = 1197,
	["Baleroc"] = 1200,
	["Ragnaros"] = 1203,
	["Lord Rhyolith"] = 1204,
	["Shannox"] = 1205,
	["Alysrazor"] = 1206,
	["Occu'thar"] = 1250,
	["Second Echo"] = 1268,
	["First Echo"] = 1269,
	["Murozond"] = 1271,
	["Peroth'arn"] = 1272,
	["Queen Azshara"] = 1273,
	["Mannoroth"] = 1274,
	["Spine of Deathwing"] = 1291,
	["Morchok"] = 1292,
	["Warlord Zon'ozz"] = 1294,
	["Yor'sahj the Unsleeping"] = 1295,
	["Hagara"] = 1296,
	["Ultraxion"] = 1297,
	["Warmaster Blackhorn"] = 1298,
	["Madness of Deathwing"] = 1299,
	["Gu Cloudstrike"] = 1303,
	["Master Snowdrift"] = 1304,
	["Sha of Violence"] = 1305,
	["Taran Zhu"] = 1306,
	["Alizabal"] = 1332,
	["Arcurion"] = 1337,
	["Archbishop Benedictus"] = 1339,
	["Asira Dawnslayer"] = 1340,
	["Omar the Test Dragon"] = 1348,
	["Feng the Accursed"] = 1390,
	["The Stone Guard"] = 1395,
	["Saboteur Kip'tilak"] = 1397,
	["Striker Ga'dok"] = 1405,
	["Commander Ri'mok"] = 1406,
	["Will of the Emperor"] = 1407,
	["Protectors of the Endless"] = 1409,
	["Ook-Ook"] = 1412,
	["Hoptallus"] = 1413,
	["Yan-Zhu the Uncasked"] = 1414,
	["Liu Flameheart"] = 1416,
	["Lorewalker Stonestep"] = 1417,
	["Wise Mari"] = 1418,
	["Raigonn"] = 1419,
	["Flameweaver Koegler"] = 1420,
	["Armsmaster Harlan"] = 1421,
	["Houndmaster Braun"] = 1422,
	["Thalnos the Soulrender"] = 1423,
	["Brother Korloff"] = 1424,
	["High Inquisitor Whitemane"] = 1425,
	["Instructor Chillheart"] = 1426,
	["Jandice Barov"] = 1427,
	["Rattlegore"] = 1428,
	["Lilian Voss"] = 1429,
	["Darkmaster Gandling"] = 1430,
	["Sha of Fear"] = 1431,
	["Gara'jal the Spiritbinder"] = 1434,
	["The Spirit Kings"] = 1436,
	["Sha of Doubt"] = 1439,
	["Xin the Weaponmaster"] = 1441,
	["Trial of the King"] = 1442,
	["Adarogg"] = 1443,
	["Dark Shaman Koranthal"] = 1444,
	["Slagmaw"] = 1445,
	["Lava Guard Gordoth"] = 1446,
	["General Pa'valak"] = 1447,
	["Garalon"] = 1463,
	["Wing Leader Ner'onok"] = 1464,
	["Vizier Jin'bak"] = 1465,
	["Wind Lord Mel'jarak"] = 1498,
	["Amber-Shaper Un'sok"] = 1499,
	["Elegon"] = 1500,
	["Grand Empress Shek'zeer"] = 1501,
	["Commander Vo'jak"] = 1502,
	["Blade Lord Ta'yak"] = 1504,
	["Tsulong"] = 1505,
	["Lei Shi"] = 1506,
	["Imperial Vizier Zor'lok"] = 1507,
	["Gekkan"] = 1509,
	["Gekkan"] = 1510,
	["Iron Qon"] = 1559,
	["Twin Empyreans"] = 1560,
	["Galleon"] = 1563,
	["Sha of Anger"] = 1564,
	["Tortos"] = 1565,
	["Council of Elders"] = 1570,
	["Nalak"] = 1571,
	["Durumu the Forgotten"] = 1572,
	["Ji-Kun"] = 1573,
	["Primordius"] = 1574,
	["Horridon"] = 1575,
	["Dark Animus"] = 1576,
	["Jin'rokh the Breaker"] = 1577,
	["Megaera"] = 1578,
	["Lei Shen"] = 1579,
	["Ra-den"] = 1580,
	["Ra-den"] = 1581,
	["Oondasta"] = 1587,
	["Paragons of the Klaxxi"] = 1593,
	["Spoils of Pandaria"] = 1594,
	["Malkorok"] = 1595,
	["Fallen Protectors"] = 1598,
	["Thok the Bloodthirsty"] = 1599,
	["Iron Juggernaut"] = 1600,
	["Siegecrafter Blackfuse"] = 1601,
	["Immerseus"] = 1602,
	["General Nazgrim"] = 1603,
	["Sha of Pride"] = 1604,
	["Omar's Test Encounter (Cosmetic only) DNT"] = 1605,
	["Kor'kron Dark Shaman"] = 1606,
	["Galakras"] = 1622,
	["Garrosh Hellscream"] = 1623,
	["Norushen"] = 1624,
	["Exarch Maladaar"] = 1889,
	["Shirrak the Dead Watcher"] = 1890,
	["Omor the Unscarred"] = 1891,
	["Vazruden the Herald"] = 1892,
	["Watchkeeper Gargolmar"] = 1893,
	["Kael'thas Sunstrider"] = 1894,
	["Priestess Delrissa"] = 1895,
	["Selin Fireheart"] = 1897,
	["Vexallus"] = 1898,
	["Nexus-Prince Shaffar"] = 1899,
	["Pandemonius"] = 1900,
	["Tavarok"] = 1901,
	["Talon King Ikiss"] = 1902,
	["Darkweaver Syth"] = 1903,
	["Anzu"] = 1904,
	["Lieutenant Drake"] = 1905,
	["Epoch Hunter"] = 1906,
	["Captain Skarloc"] = 1907,
	["Ambassador Hellmaw"] = 1908,
	["Blackheart the Inciter"] = 1909,
	["Murmur"] = 1910,
	["Grandmaster Vorpil"] = 1911,
	["Dalliah the Doomsayer"] = 1913,
	["Harbinger Skyriss"] = 1914,
	["Wrath-Scryer Soccothrates"] = 1915,
	["Zereketh the Unbound"] = 1916,
	["Aeonus"] = 1919,
	["Chrono Lord Deja"] = 1920,
	["Temporus"] = 1921,
	["The Maker"] = 1922,
	["Keli'dan the Breaker"] = 1923,
	["Broggok"] = 1924,
	["Commander Sarannis"] = 1925,
	["High Botanist Freywinn"] = 1926,
	["Laj"] = 1927,
	["Thorngrin the Tender"] = 1928,
	["Warp Splinter"] = 1929,
	["Nethermancer Sepethrea"] = 1930,
	["Pathaleon the Calculator"] = 1931,
	["Mechano-Lord Capacitus"] = 1932,
	["Gatewatcher Gyro-Kill"] = 1933,
	["Gatewatcher Iron-Hand"] = 1934,
	["Blood Guard Porung"] = 1935,
	["Grand Warlock Nethekurse"] = 1936,
	["Warbringer O'mrogg"] = 1937,
	["Warchief Kargath Bladefist"] = 1938,
	["Mennu the Betrayer"] = 1939,
	["Quagmirran"] = 1940,
	["Rokmar the Crackler"] = 1941,
	["Hydromancer Thespia"] = 1942,
	["Mekgineer Steamrigger"] = 1943,
	["Warlord Kalithresh"] = 1944,
	["Ghaz'an"] = 1945,
	["Hungarfen"] = 1946,
	["Swamplord Musel'ek"] = 1947,
	["The Black Stalker"] = 1948,
	["Eck the Ferocious"] = 1988,
	["Amanitar"] = 1989,
	["Erekem"] = 2658,
	["Moragg"] = 2659,
	["Ichoron"] = 2660,
	["Xevozz"] = 2661,
	["Lavanthor"] = 2662,
	["Zuramat"] = 2663,
};

local entries = 0;
local entryErrors = {};
local function updateSavedVariables()
	local count = 0;
	for k, v in pairs(encounterData) do
		count = count + 1;
	end
	--NRC:debug(encounterData)
	NEEdatabase = encounterData;
	--NEE:printOutput(); --Print table to chat.
	NEE:openCopyFrame(); --Open a copy text frame with the table ready to ctrl + v.
	print("Encounter DB exported - entries found: " .. entries .. " Matched to an encounterID: " .. count);
	local errorCount = 0;
	if (entries > count) then
		for k, v in pairs(entryErrors) do
			errorCount = errorCount + 1;
			print("Error" .. errorCount .. ": " .. k .. " JournalDungeonID: " .. v);
		end
	end
end

local function debug(...)
	local data = ...;
	if (data) then
		if (type(data) == "table") then
			UIParentLoadAddOn("Blizzard_DebugTools");
			--DevTools_Dump(data);
    		DisplayTableInspectorWindow(data);
    	else
			print("TEDebug:", ...);
		end
	end
end

local function pairsByKeys(t, f)
	local a = {};
	for n in pairs(t) do
		tinsert(a, n);
	end
	table.sort(a, f);
	local i = 0;
	local iter = function()
		i = i + 1;
		if (a[i] == nil) then
			return nil;
		else
			return a[i], t[a[i]];
		end
	end
	return iter;
end

--local tooltipScanner = CreateFrame("GameTooltip", "NEETooltipScanner", nil, "GameTooltipTemplate");
--tooltipScanner:SetOwner(WorldFrame, "ANCHOR_NONE");
local names = {};
function NEE:generateEncounterData()
	C_AddOns.LoadAddOn("Blizzard_EncounterJournal");
	encounterData = {};
	names = {};
	entries = 0;
	entryErrors = {};
	local instances = {};
	for k, v in pairs(EJNAV_GetInstanceList()) do
		local journalInstanceID, name = EJ_GetInstanceByIndex(k, false); --Change to true for raids, false for dungeons.
		tinsert(instances, journalInstanceID)
	end
	--Scan only the expansion being viewed in the journal.
	--Will show classic era on logon, run the command once viewing expansion mage in the journal: /run NEE:generateEncounterData()
	for k, v in ipairs(instances) do
		EJ_SelectInstance(v);
		for i = 1, 30 do
			local name, _, journalEncounterID, _, _, _, encounterID = EJ_GetEncounterInfoByIndex(i);
			if (name) then
				entries = entries + 1;
				if (encounterID) then
					encounterData[encounterID] = journalEncounterID;
					names[journalEncounterID] = name;
				else
					entryErrors[name] = journalEncounterID;
				end
			end
		end
	end
	
	--Scan all IDs
	--[[EJ_SelectInstance(63);
	for i = 1, 4000 do --/dump 672
		local name, _, journalEncounterID, _, _, _, encounterID = EJ_GetEncounterInfo(i);
		if (name and encounterID) then
			--print(EJ_GetEncounterInfoByIndex(i))
			entries = entries + 1;
			encounterData[encounterID] = journalEncounterID;
			names[journalEncounterID] = name;
			print(i, entries)
		end
	end]]
	
	--Scan using the wago db above.
	--for k, v in ipairs(instances) do
	--	EJ_SelectInstance(v);
	--	for i = 1, 30 do
	--		local name, _, journalEncounterID = EJ_GetEncounterInfoByIndex(i);
	--		if (name) then
	--			entries = entries + 1;
	--			--[name] = data[name];
	--			if (data[name]) then
	--				names[journalEncounterID] = name;
	--				encounterData[data[name]] = journalEncounterID;
	--			else
	--				entryErrors[name] = journalEncounterID;
	--			end
	--		end
	--	end
	--end
	updateSavedVariables();
end

local f = CreateFrame("Frame");
f:RegisterEvent("PLAYER_ENTERING_WORLD");
f:SetScript("OnEvent", function(self, event, ...)
	NEE:generateEncounterData();
	f:UnregisterEvent("PLAYER_ENTERING_WORLD");
end)


--Print to chat when we record, it's a neater table structure to copy and paste than the saved variables file.
function NEE:printOutput()
	local _, class = UnitClass("player");
	print("NRC.encounterIDJournalMap = {");
	for k, v in pairs(encounterData) do
		print("    [" .. k .. "] = " .. v .. ",");
	end
	print("};");
end

local NEECopyFrame = CreateFrame("ScrollFrame", "NEECopyFrame", nil, "BackdropTemplate,InputScrollFrameTemplate");
NEECopyFrame:Hide();
NEECopyFrame:SetToplevel(true);
NEECopyFrame:SetMovable(true);
NEECopyFrame:EnableMouse(true);
NEECopyFrame:SetHeight(245);
NEECopyFrame:SetWidth(400);
NEECopyFrame.EditBox:SetWidth(NEECopyFrame:GetWidth() - 30);
tinsert(UISpecialFrames, "NEECopyFrame");
NEECopyFrame:SetPoint("CENTER", UIParent, -100, 100);
NEECopyFrame:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8x8",insets = {top = 0, left = 0, bottom = 0, right = 0}});
NEECopyFrame:SetBackdropColor(0,0,0,.5);
NEECopyFrame.CharCount:Hide();
NEECopyFrame:SetFrameLevel(129);
NEECopyFrame:SetFrameStrata("TOOLTIP");
local NEECopyFrameTopBar = CreateFrame("Frame", "NEECopyFrameTopBar", NEECopyFrame, "ThinGoldEdgeTemplate");
NEECopyFrameTopBar:SetPoint("TOP", -8, 22);
NEECopyFrameTopBar:SetWidth(120);
NEECopyFrameTopBar:SetHeight(18);
NEECopyFrameTopBar.fs = NEECopyFrameTopBar:CreateFontString("topBarFS", "OVERLAY", "NumberFont_Shadow_Tiny");
NEECopyFrameTopBar.fs:SetText("|cFFFFFF00Nova Encounter Exporter");
NEECopyFrameTopBar.fs:SetPoint("CENTER", 0, 0);
NEECopyFrameTopBar:SetMovable(true);
NEECopyFrameTopBar:EnableMouse(true);
NEECopyFrameTopBar:SetScript("OnMouseDown", function(self, button)
	if (button == "LeftButton" and not self:GetParent().isMoving) then
		self:GetParent():StartMoving();
		self:GetParent().isMoving = true;
	end
end)
NEECopyFrameTopBar:SetScript("OnMouseUp", function(self, button)
	if (button == "LeftButton" and self:GetParent().isMoving) then
		self:GetParent():StopMovingOrSizing();
		self:GetParent().isMoving = false;
	end
end)
NEECopyFrameTopBar:SetScript("OnHide", function(self)
	if (self:GetParent().isMoving) then
		self:GetParent():StopMovingOrSizing();
		self:GetParent().isMoving = false;
	end
end)

--Top right X close button
local NEECopyFrameCloseButton = CreateFrame("Button", "NEECopyFrameCloseButton", NEECopyFrame, "UIPanelCloseButton");
NEECopyFrameCloseButton:SetPoint("TOPRIGHT", 12, 27);
NEECopyFrameCloseButton:SetWidth(29);
NEECopyFrameCloseButton:SetHeight(29);
NEECopyFrameCloseButton:SetScript("OnClick", function(self, arg)
	NEECopyFrame:Hide();
end)

function NEE:openCopyFrame()
	NEECopyFrame.EditBox:SetFont("Fonts\\ARIALN.ttf", 11, "");
	NEECopyFrame.EditBox:SetText("");
	local _, class = UnitClass("player");
	local text = "NRC.encounterIDJournalMap = {";
	for k, v in pairs(encounterData) do
		text = text .. "\n    [" .. k .. "] = " .. v .. ", --" .. (names[v] or "Unknown") .. ".";
	end
	text = text .. "\n};";
	NEECopyFrame.EditBox:Insert(text);
	NEECopyFrame:Show();
	NEECopyFrame.EditBox:HighlightText();
	NEECopyFrame.EditBox:SetFocus();
end